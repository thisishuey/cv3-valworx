/*
  You can add/edit your JavaScript below.
  To utilize this script in your store, add the following
  line to your store's templates where necessary: 

  <script type="text/javascript" src="/bootstrap-min.js"></script>
*/
